The IQueue program requires an aspi layer to enable 
the CD burning capability.  To install the aspi layer
 follow this procedure:

1. double click the killaspi.bat file.  This will
   remove any legacy aspi files that may exist on the
   pc.
2. double click the aspikit.exe file.  This will install
   the Nexitech aspi dirvier (v1.18).
3. Reboot the computer.

If you are connecting IQueue to a Noritsu 2611 printer
(mini-lab enabled and no Gretag printer is present), you
will need to also install a the Adaptec aspi dirver.
To install the adaptec aspi driver, follow this procedure:

1. open the Noritsu2611 folder
2. double click the installaspi.bat file
3. Reboot the computer.
